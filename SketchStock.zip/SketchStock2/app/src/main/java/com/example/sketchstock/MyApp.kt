package com.example.sketchstock

import android.app.Application
import com.google.firebase.FirebaseApp

class MyApp : Application() {

    override fun onCreate() {
        super.onCreate()
        //Inicializaión de Firebase
        FirebaseApp.initializeApp(this)
    }
}
