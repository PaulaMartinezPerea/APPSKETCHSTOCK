package com.example.sketchstock.model

data class User(
    val nombre: String = "",
    val telefono: String = "",
    val email: String = ""
)
